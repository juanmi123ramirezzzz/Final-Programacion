import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner linea = new Scanner(System.in);
		
	int numeroplantas = 3;
	int agente = 1;
	
	PlantaGeneracion[] plantas = new PlantaGeneracion[numeroplantas];
	for(int i=0;i<numeroplantas;i++) {
		System.out.println("Ingrese el ID de la planta");
		int id = linea.nextInt();
		System.out.println("Ingrese el recurso de la planta");
		String recurso = linea.next();
		System.out.println("Ingrese la ciudad donde esta la planta");
		String ciudad = linea.next();
		System.out.println("Ingrese la fecha de la creacición de la planta");
		String fechainicial = linea.next();
		System.out.println("Ingrese el factor de disponibilidad");
		double factordeDisponilidad = linea.nextDouble();
		System.out.println("Ingrese el presupuesto de mantenimiento");
		double dineroDisponible = linea.nextDouble();
		String fechas [] = new String [2];
		plantas[i] = new PlantaGeneracion (id, recurso,ciudad,fechainicial,fechas,factordeDisponilidad,dineroDisponible);
		System.out.println("Información acerca de esta planta: " + plantas[i].planta());
		
			
		}
		AgenteMercado[] agentes = new AgenteMercado [agente];
		for(int i=0; i<agente;i++) {
			System.out.println("Ingrese el nombre del agente");
			String nombre = linea.next();
			System.out.println("Ingrese el ID del agente");
			int id = linea.nextInt();
			System.out.println("Ingrese la ciudad de residencia del agente");
			String ciudad = linea.next();
			PlantaGeneracion[]plantaGeneracion;
			String presidente = linea.next();
			System.out.println("Ingrese el dinero disponible");
			double dineroDisponible = linea.nextDouble();
			
			agentes[i]=new AgenteMercado(id,nombre,plantas,ciudad,presidente,dineroDisponible);
			System.out.println("Información acerca del agente: " + agentes[i].mostrardatos());
			
			
		
		}
		
		
		
		
	}
	
		
	}

