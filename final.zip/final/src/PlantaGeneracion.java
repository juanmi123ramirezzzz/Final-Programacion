
public class PlantaGeneracion {
private int id;
private String recurso;
private String ciudad;
private String fechainicial;
private String fechasMantenimiento[];
private double factordeDisponibilidad;
private double presupuestoMantenimiento;
public void realizarMantenimiento(double a) {
	presupuestoMantenimiento=-a;
}
public PlantaGeneracion(int id, String recurso, String ciudad, String fechainicial, String[] fechasMantenimiento,
		double factordeDisponibilidad, double presupuestoMantenimiento) {
	super();
	this.id = id;
	this.recurso = recurso;
	this.ciudad = ciudad;
	this.fechainicial = fechainicial;
	this.fechasMantenimiento = fechasMantenimiento;
	this.factordeDisponibilidad = factordeDisponibilidad;
	this.presupuestoMantenimiento = presupuestoMantenimiento;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getRecurso() {
	return recurso;
}
public void setRecurso(String recurso) {
	this.recurso = recurso;
}
public String getCiudad() {
	return ciudad;
}
public void setCiudad(String ciudad) {
	this.ciudad = ciudad;
}
public String getFechainicial() {
	return fechainicial;
}
public void setFechainicial(String fechainicial) {
	this.fechainicial = fechainicial;
}
public String[] getFechasMantenimiento() {
	return fechasMantenimiento;
}
public void setFechasMantenimiento(String[] fechasMantenimiento) {
	this.fechasMantenimiento = fechasMantenimiento;
}
public double getFactordeDisponibilidad() {
	return factordeDisponibilidad;
}
public void setFactordeDisponibilidad(double factordeDisponibilidad) {
	this.factordeDisponibilidad = factordeDisponibilidad;
}
public double getPresupuestoMantenimiento() {
	return presupuestoMantenimiento;
}
public void setPresupuestoMantenimiento(double presupuestoMantenimiento) {
	this.presupuestoMantenimiento = presupuestoMantenimiento;
}

public String planta () {
	return "El ID de la planta es " + id + ", el recurso que produce es " + recurso + " y el proceso se inicio el dia " + fechainicial + 
			". Su factor de disponibilidad es " + factordeDisponibilidad + ", y actualmente cuenta con un presupuesto de mantenimiento de " 
			+ presupuestoMantenimiento +" millones de pesos.";
	
}
}
